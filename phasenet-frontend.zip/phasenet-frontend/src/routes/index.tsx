import { createBrowserRouter } from 'react-router-dom'
import MainLayout from '@/layouts/MainLayout'
import HomePage from '@/pages/Home'
import PredictionPage from '@/pages/Prediction'
import ResultsPage from '@/pages/Results'
import AboutPage from '@/pages/About'

// MainLayout needs props — we wrap it at App level instead.
// Here we export the route tree config.
export const routeConfig = [
  {
    path: '/',
    element: null, // replaced in App.tsx with <MainLayout>
    children: [
      { index: true, element: <HomePage /> },
      { path: 'predict', element: <PredictionPage /> },
      { path: 'results', element: <ResultsPage /> },
      { path: 'about', element: <AboutPage /> },
    ],
  },
]

export { HomePage, PredictionPage, ResultsPage, AboutPage, MainLayout }
