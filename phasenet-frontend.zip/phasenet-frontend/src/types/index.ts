// ─── API Request Types ────────────────────────────────────────────────────────

/** POST /api/predict/ request body.
 *  data[0] = East channel   (6000 float values)
 *  data[1] = North channel  (6000 float values)
 *  data[2] = Vertical channel (6000 float values)
 */
export interface PredictRequest {
  data: [number[], number[], number[]]
}

// ─── API Response Types ───────────────────────────────────────────────────────

export interface PhasePickResult {
  detected: boolean
  sample_index: number
  time_seconds: number
  confidence: number
}

export interface PredictionResult {
  is_earthquake: boolean
  detection_probability: number
  detection_threshold: number
  p_phase: PhasePickResult
  s_phase: PhasePickResult
  p_arrival_probs: number[]
  s_arrival_probs: number[]
}

export interface PredictResponse {
  success: boolean
  predictions: PredictionResult
}

export interface HealthResponse {
  status: 'ok' | 'error'
  model_loaded: boolean
  device: 'cuda' | 'cpu'
}

// ─── API Error ────────────────────────────────────────────────────────────────

export interface ApiError {
  message: string
  detail?: string
  status?: number
}

// ─── Form / UI Types ──────────────────────────────────────────────────────────

export type InputMethod = 'json' | 'csv' | 'manual'

export interface WaveformFormValues {
  inputMethod: InputMethod
  jsonInput: string
  eastChannel: string
  northChannel: string
  verticalChannel: string
}

export interface ChannelData {
  east: number[]
  north: number[]
  vertical: number[]
}

export type ThemeMode = 'light' | 'dark'

// ─── Chart data ───────────────────────────────────────────────────────────────

export interface ProbabilityCurvePoint {
  sample: number
  timeSeconds: number
  pProb: number
  sProb: number
}
