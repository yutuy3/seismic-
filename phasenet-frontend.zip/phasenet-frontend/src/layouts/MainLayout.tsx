import { Box } from '@mui/material'
import { Outlet } from 'react-router-dom'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'

interface MainLayoutProps {
  themeMode: 'light' | 'dark'
  onThemeToggle: () => void
}

export default function MainLayout({ themeMode, onThemeToggle }: MainLayoutProps) {
  return (
    <Box display="flex" flexDirection="column" minHeight="100vh">
      <Navbar themeMode={themeMode} onThemeToggle={onThemeToggle} />
      <Box component="main" flexGrow={1}>
        <Outlet />
      </Box>
      <Footer />
    </Box>
  )
}
