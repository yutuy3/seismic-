import { z } from 'zod'

export const N_SAMPLES = 6000
export const N_CHANNELS = 3

// ── Individual channel string validator ──────────────────────────────────────
const channelStringSchema = z
  .string()
  .min(1, 'Channel data is required.')
  .transform((val) => val.split(',').map((s) => parseFloat(s.trim())))
  .refine((arr) => arr.every((v) => !isNaN(v)), {
    message: 'All values must be valid numbers.',
  })
  .refine((arr) => arr.length === N_SAMPLES, {
    message: `Each channel must contain exactly ${N_SAMPLES} values (60 s × 100 Hz).`,
  })

// ── JSON input validator ─────────────────────────────────────────────────────
export const jsonInputSchema = z.object({
  inputMethod: z.literal('json'),
  jsonInput: z
    .string()
    .min(1, 'JSON input is required.')
    .superRefine((val, ctx) => {
      let parsed: unknown
      try {
        parsed = JSON.parse(val)
      } catch {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Invalid JSON format.' })
        return
      }
      if (!Array.isArray(parsed) || parsed.length !== N_CHANNELS) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `JSON must be an array of ${N_CHANNELS} channels.`,
        })
        return
      }
      parsed.forEach((ch, i) => {
        if (!Array.isArray(ch) || ch.length !== N_SAMPLES) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `Channel ${i} must have exactly ${N_SAMPLES} values.`,
          })
        }
        if (!ch.every((v: unknown) => typeof v === 'number' && !isNaN(v as number))) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: `Channel ${i} contains non-numeric values.`,
          })
        }
      })
    }),
  eastChannel: z.string().optional(),
  northChannel: z.string().optional(),
  verticalChannel: z.string().optional(),
})

// ── Manual / CSV channel entry validator ─────────────────────────────────────
export const manualInputSchema = z.object({
  inputMethod: z.enum(['manual', 'csv']),
  jsonInput: z.string().optional(),
  eastChannel: channelStringSchema,
  northChannel: channelStringSchema,
  verticalChannel: channelStringSchema,
})

export const waveformSchema = z.discriminatedUnion('inputMethod', [
  jsonInputSchema,
  manualInputSchema,
])

export type WaveformSchemaType = z.infer<typeof waveformSchema>
