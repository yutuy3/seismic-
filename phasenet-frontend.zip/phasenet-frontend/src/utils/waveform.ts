import type { ChannelData, ProbabilityCurvePoint, PredictionResult } from '@/types'
import { N_SAMPLES } from './validation'

/** Parse a raw JSON string into three float arrays */
export function parseJsonWaveform(json: string): ChannelData {
  const parsed = JSON.parse(json) as number[][]
  return {
    east: parsed[0],
    north: parsed[1],
    vertical: parsed[2],
  }
}

/** Parse a comma-separated string into a float array */
export function parseChannelString(s: string): number[] {
  return s.split(',').map((v) => parseFloat(v.trim()))
}

/** Downsample a probability array to `targetPoints` evenly-spaced points.
 *  Avoids rendering 6000 SVG path segments in Recharts.
 */
export function downsampleProbs(
  pProbs: number[],
  sProbs: number[],
  targetPoints = 600,
): ProbabilityCurvePoint[] {
  const step = Math.max(1, Math.floor(N_SAMPLES / targetPoints))
  const result: ProbabilityCurvePoint[] = []
  for (let i = 0; i < N_SAMPLES; i += step) {
    result.push({
      sample: i,
      timeSeconds: parseFloat((i / 100).toFixed(2)),
      pProb: parseFloat((pProbs[i] ?? 0).toFixed(4)),
      sProb: parseFloat((sProbs[i] ?? 0).toFixed(4)),
    })
  }
  return result
}

/** Format seconds to mm:ss.d */
export function formatSeconds(s: number): string {
  const mins = Math.floor(s / 60)
  const secs = (s % 60).toFixed(1)
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`
}

/** Return a colour label for detection confidence */
export function detectionColor(prob: number): 'success' | 'warning' | 'error' {
  if (prob >= 0.75) return 'success'
  if (prob >= 0.5) return 'warning'
  return 'error'
}

/** Generate a synthetic demo waveform (pure noise + impulse) for quick testing */
export function generateDemoWaveform(): ChannelData {
  const n = N_SAMPLES
  const noise = () =>
    Array.from({ length: n }, (_, i) => {
      // simple sinusoidal with random noise
      return (
        0.3 * Math.sin((2 * Math.PI * 5 * i) / 100) +
        0.1 * (Math.random() * 2 - 1) +
        (i > 2100 && i < 2300 ? 0.8 * Math.sin((2 * Math.PI * 20 * (i - 2100)) / 100) : 0)
      )
    })
  return { east: noise(), north: noise(), vertical: noise() }
}

/** Serialize ChannelData into the API request shape */
export function channelDataToRequest(
  ch: ChannelData,
): [number[], number[], number[]] {
  return [ch.east, ch.north, ch.vertical]
}

/** Compute S-P time difference in seconds */
export function spTimeDiff(result: PredictionResult): number | null {
  if (!result.p_phase.detected || !result.s_phase.detected) return null
  return parseFloat(
    (result.s_phase.time_seconds - result.p_phase.time_seconds).toFixed(2),
  )
}
