import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts'
import { Box, Typography, useTheme } from '@mui/material'
import { downsampleProbs } from '@/utils/waveform'
import type { PredictionResult } from '@/types'

interface ConfidenceChartProps {
  predictions: PredictionResult
}

export default function ConfidenceChart({ predictions }: ConfidenceChartProps) {
  const theme = useTheme()
  const data = downsampleProbs(
    predictions.p_arrival_probs,
    predictions.s_arrival_probs,
    600,
  )

  const pColor = '#00D4C8'
  const sColor = '#6C63FF'

  const pSampleDownsampled = Math.round(predictions.p_phase.sample_index / 10)
  const sSampleDownsampled = Math.round(predictions.s_phase.sample_index / 10)

  return (
    <Box>
      <Typography variant="h6" fontWeight={600} mb={1}>
        Phase Probability Curves
      </Typography>
      <Typography variant="body2" color="text.secondary" mb={2}>
        P-wave (teal) and S-wave (violet) arrival probability over the 60-second window.
        Vertical markers indicate detected picks.
      </Typography>

      <ResponsiveContainer width="100%" height={320}>
        <ComposedChart data={data} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
          <CartesianGrid
            strokeDasharray="3 3"
            stroke={theme.palette.divider}
            opacity={0.5}
          />
          <XAxis
            dataKey="timeSeconds"
            label={{ value: 'Time (s)', position: 'insideBottomRight', offset: -8 }}
            tickFormatter={(v: number) => `${v}s`}
            tick={{ fill: theme.palette.text.secondary, fontSize: 11 }}
          />
          <YAxis
            domain={[0, 1]}
            tickFormatter={(v: number) => `${(v * 100).toFixed(0)}%`}
            tick={{ fill: theme.palette.text.secondary, fontSize: 11 }}
            width={48}
          />
          <Tooltip
            formatter={(value: number, name: string) => [
              `${(value * 100).toFixed(1)}%`,
              name === 'pProb' ? 'P-wave probability' : 'S-wave probability',
            ]}
            labelFormatter={(label: number) => `t = ${label}s`}
            contentStyle={{
              background: theme.palette.background.paper,
              border: `1px solid ${theme.palette.divider}`,
              borderRadius: 8,
              fontSize: 12,
            }}
          />
          <Legend
            formatter={(value: string) =>
              value === 'pProb' ? 'P-wave probability' : 'S-wave probability'
            }
          />

          {/* P pick */}
          {predictions.p_phase.detected && (
            <ReferenceLine
              x={data[pSampleDownsampled]?.timeSeconds}
              stroke={pColor}
              strokeWidth={2}
              strokeDasharray="6 3"
              label={{
                value: `P ${predictions.p_phase.time_seconds}s`,
                fill: pColor,
                fontSize: 11,
                fontWeight: 700,
              }}
            />
          )}

          {/* S pick */}
          {predictions.s_phase.detected && (
            <ReferenceLine
              x={data[sSampleDownsampled]?.timeSeconds}
              stroke={sColor}
              strokeWidth={2}
              strokeDasharray="6 3"
              label={{
                value: `S ${predictions.s_phase.time_seconds}s`,
                fill: sColor,
                fontSize: 11,
                fontWeight: 700,
              }}
            />
          )}

          <Line
            type="monotone"
            dataKey="pProb"
            stroke={pColor}
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4 }}
          />
          <Line
            type="monotone"
            dataKey="sProb"
            stroke={sColor}
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4 }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </Box>
  )
}
