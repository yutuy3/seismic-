import { Box, CircularProgress, Typography } from '@mui/material'

interface LoadingSpinnerProps {
  message?: string
  size?: number
  fullScreen?: boolean
}

export default function LoadingSpinner({
  message = 'Loading…',
  size = 48,
  fullScreen = false,
}: LoadingSpinnerProps) {
  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      gap={2}
      sx={
        fullScreen
          ? { position: 'fixed', inset: 0, zIndex: 9999, bgcolor: 'background.default' }
          : { py: 8 }
      }
    >
      <CircularProgress size={size} thickness={4} color="primary" />
      {message && (
        <Typography variant="body2" color="text.secondary">
          {message}
        </Typography>
      )}
    </Box>
  )
}
