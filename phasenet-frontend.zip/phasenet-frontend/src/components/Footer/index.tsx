import { Box, Typography, Link, Divider } from '@mui/material'
import WavesIcon from '@mui/icons-material/Waves'

export default function Footer() {
  return (
    <Box component="footer" sx={{ mt: 'auto', py: 4 }}>
      <Divider />
      <Box
        display="flex"
        flexDirection={{ xs: 'column', sm: 'row' }}
        alignItems="center"
        justifyContent="space-between"
        gap={2}
        sx={{ px: { xs: 2, md: 6 }, pt: 3 }}
      >
        <Box display="flex" alignItems="center" gap={1}>
          <WavesIcon sx={{ color: 'primary.main', fontSize: 20 }} />
          <Typography variant="body2" fontWeight={700}>
            PhaseNet
          </Typography>
          <Typography variant="body2" color="text.secondary">
            · Seismic Phase Picker
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary">
          PyTorch · Django REST Framework · STEAD Dataset
        </Typography>

        <Typography variant="body2" color="text.secondary">
          <Link href="/api/docs/" target="_blank" rel="noopener" color="primary" underline="hover">
            Swagger Docs
          </Link>
          {' · '}
          <Link href="/api/redoc/" target="_blank" rel="noopener" color="primary" underline="hover">
            ReDoc
          </Link>
        </Typography>
      </Box>
    </Box>
  )
}
