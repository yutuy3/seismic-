import { Box, Chip, Tooltip } from '@mui/material'
import CircleIcon from '@mui/icons-material/Circle'
import { useHealth } from '@/hooks/usePhaseNet'

export default function StatusIndicator() {
  const { data, isLoading, isError } = useHealth()

  if (isLoading) {
    return (
      <Chip
        size="small"
        icon={<CircleIcon sx={{ fontSize: 10, color: 'warning.main !important' }} />}
        label="Checking…"
        variant="outlined"
      />
    )
  }

  if (isError || !data || data.status !== 'ok' || !data.model_loaded) {
    return (
      <Tooltip title="Backend unreachable or model not loaded">
        <Chip
          size="small"
          icon={<CircleIcon sx={{ fontSize: 10, color: 'error.main !important' }} />}
          label="Offline"
          color="error"
          variant="outlined"
        />
      </Tooltip>
    )
  }

  return (
    <Tooltip title={`Backend online · Model loaded · Device: ${data.device.toUpperCase()}`}>
      <Box display="flex" alignItems="center" gap={0.5}>
        <Chip
          size="small"
          icon={<CircleIcon sx={{ fontSize: 10, color: 'success.main !important' }} />}
          label={`Online · ${data.device.toUpperCase()}`}
          color="success"
          variant="outlined"
        />
      </Box>
    </Tooltip>
  )
}
