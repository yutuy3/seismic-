import { useRef, useState } from 'react'
import { Box, Button, Typography, Paper, LinearProgress } from '@mui/material'
import UploadFileIcon from '@mui/icons-material/UploadFile'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import { N_SAMPLES } from '@/utils/validation'

interface FileUploadProps {
  onParsed: (east: number[], north: number[], vertical: number[]) => void
  onError: (msg: string) => void
}

/**
 * Accepts a CSV file with 3 rows × 6000 columns (or 6000 rows × 3 columns).
 * Auto-detects orientation.
 */
export default function FileUpload({ onParsed, onError }: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const handleFile = (file: File) => {
    setFileName(file.name)
    setLoading(true)
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string
        const rows = text
          .trim()
          .split('\n')
          .map((row) => row.split(',').map((v) => parseFloat(v.trim())))

        let east: number[], north: number[], vertical: number[]

        if (rows.length === 3 && rows[0].length === N_SAMPLES) {
          // 3 rows × 6000 cols
          ;[east, north, vertical] = rows
        } else if (rows.length === N_SAMPLES && rows[0].length === 3) {
          // 6000 rows × 3 cols
          east = rows.map((r) => r[0])
          north = rows.map((r) => r[1])
          vertical = rows.map((r) => r[2])
        } else {
          throw new Error(
            `Expected shape [3 × ${N_SAMPLES}] or [${N_SAMPLES} × 3], got [${rows.length} × ${rows[0]?.length}].`,
          )
        }

        if ([...east, ...north, ...vertical].some((v) => isNaN(v))) {
          throw new Error('CSV contains non-numeric values.')
        }

        onParsed(east, north, vertical)
      } catch (err) {
        onError((err as Error).message)
      } finally {
        setLoading(false)
      }
    }
    reader.readAsText(file)
  }

  return (
    <Paper
      variant="outlined"
      sx={{
        borderStyle: 'dashed',
        borderRadius: 3,
        p: 4,
        textAlign: 'center',
        cursor: 'pointer',
        transition: 'border-color 0.2s',
        '&:hover': { borderColor: 'primary.main' },
      }}
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault()
        const file = e.dataTransfer.files[0]
        if (file) handleFile(file)
      }}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".csv,.txt"
        hidden
        onChange={(e) => {
          const file = e.target.files?.[0]
          if (file) handleFile(file)
        }}
      />

      {loading ? (
        <Box>
          <Typography variant="body2" color="text.secondary" mb={1}>
            Parsing CSV…
          </Typography>
          <LinearProgress color="primary" />
        </Box>
      ) : fileName ? (
        <Box display="flex" flexDirection="column" alignItems="center" gap={1}>
          <CheckCircleIcon color="success" sx={{ fontSize: 40 }} />
          <Typography variant="body2" fontWeight={600}>
            {fileName}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Loaded. Click to replace.
          </Typography>
        </Box>
      ) : (
        <Box>
          <UploadFileIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 1 }} />
          <Typography fontWeight={600} gutterBottom>
            Drop a CSV file here
          </Typography>
          <Typography variant="body2" color="text.secondary" mb={2}>
            Shape: 3 channels × 6 000 samples (60 s @ 100 Hz)
          </Typography>
          <Button variant="outlined" size="small" color="primary">
            Browse files
          </Button>
        </Box>
      )}
    </Paper>
  )
}
