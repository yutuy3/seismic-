import {
  Box,
  Card,
  CardContent,
  Chip,
  Divider,
  Grid,
  LinearProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Alert,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import CancelIcon from '@mui/icons-material/Cancel'
import TravelExploreIcon from '@mui/icons-material/TravelExplore'
import ConfidenceChart from '@/components/ConfidenceChart'
import { detectionColor, formatSeconds, spTimeDiff } from '@/utils/waveform'
import type { PredictionResult } from '@/types'

interface PredictionResultsProps {
  result: PredictionResult
}

function ConfidenceBar({ value, color }: { value: number; color: 'success' | 'warning' | 'error' }) {
  return (
    <Box display="flex" alignItems="center" gap={1}>
      <LinearProgress
        variant="determinate"
        value={value * 100}
        color={color}
        sx={{ flexGrow: 1, height: 8, borderRadius: 4 }}
      />
      <Typography variant="body2" fontWeight={700} sx={{ minWidth: 44 }}>
        {(value * 100).toFixed(1)}%
      </Typography>
    </Box>
  )
}

function PhaseCard({
  label,
  phase,
  color,
}: {
  label: string
  phase: PredictionResult['p_phase']
  color: string
}) {
  return (
    <Card variant="outlined" sx={{ height: '100%' }}>
      <CardContent>
        <Box display="flex" alignItems="center" gap={1} mb={1.5}>
          <Box
            sx={{
              width: 12,
              height: 12,
              borderRadius: '50%',
              bgcolor: color,
            }}
          />
          <Typography variant="h6" fontWeight={700}>
            {label} Phase
          </Typography>
          <Chip
            label={phase.detected ? 'Detected' : 'Not detected'}
            size="small"
            color={phase.detected ? 'success' : 'default'}
            icon={phase.detected ? <CheckCircleIcon /> : <CancelIcon />}
          />
        </Box>

        {phase.detected ? (
          <Stack spacing={1.5}>
            <Box>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                Arrival time
              </Typography>
              <Typography variant="h5" fontWeight={800} sx={{ fontFamily: 'monospace' }}>
                {formatSeconds(phase.time_seconds)}
              </Typography>
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase" display="block" mb={0.5}>
                Confidence
              </Typography>
              <ConfidenceBar value={phase.confidence} color={detectionColor(phase.confidence)} />
            </Box>
            <Box>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                Sample index
              </Typography>
              <Typography variant="body2" fontWeight={600} sx={{ fontFamily: 'monospace' }}>
                #{phase.sample_index.toLocaleString()}
              </Typography>
            </Box>
          </Stack>
        ) : (
          <Typography variant="body2" color="text.secondary">
            No {label}-wave arrival detected above the confidence threshold (0.1).
          </Typography>
        )}
      </CardContent>
    </Card>
  )
}

export default function PredictionResults({ result }: PredictionResultsProps) {
  const detColor = detectionColor(result.detection_probability)
  const spDiff = spTimeDiff(result)

  return (
    <Stack spacing={4}>
      {/* ── Detection banner ─────────────────────────────────────────────────── */}
      <Alert
        severity={result.is_earthquake ? 'warning' : 'success'}
        icon={<TravelExploreIcon />}
        sx={{ borderRadius: 3, py: 2 }}
      >
        <Typography variant="h6" fontWeight={700}>
          {result.is_earthquake ? '🌍 Seismic event detected' : '✅ No seismic event'}
        </Typography>
        <Typography variant="body2">
          Detection probability:{' '}
          <strong>{(result.detection_probability * 100).toFixed(1)}%</strong> (threshold:{' '}
          {(result.detection_threshold * 100).toFixed(0)}%)
        </Typography>
      </Alert>

      {/* ── Summary metrics row ───────────────────────────────────────────────── */}
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <Card variant="outlined">
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                Detection probability
              </Typography>
              <Typography variant="h4" fontWeight={800} color={`${detColor}.main`} sx={{ fontFamily: 'monospace' }}>
                {(result.detection_probability * 100).toFixed(1)}%
              </Typography>
              <ConfidenceBar value={result.detection_probability} color={detColor} />
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card variant="outlined">
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                P arrival
              </Typography>
              <Typography variant="h4" fontWeight={800} sx={{ fontFamily: 'monospace' }}>
                {result.p_phase.detected ? formatSeconds(result.p_phase.time_seconds) : '—'}
              </Typography>
              {result.p_phase.detected && (
                <Chip
                  label={`${(result.p_phase.confidence * 100).toFixed(0)}% conf`}
                  size="small"
                  color={detectionColor(result.p_phase.confidence)}
                />
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card variant="outlined">
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                S arrival
              </Typography>
              <Typography variant="h4" fontWeight={800} sx={{ fontFamily: 'monospace' }}>
                {result.s_phase.detected ? formatSeconds(result.s_phase.time_seconds) : '—'}
              </Typography>
              {result.s_phase.detected && (
                <Chip
                  label={`${(result.s_phase.confidence * 100).toFixed(0)}% conf`}
                  size="small"
                  color={detectionColor(result.s_phase.confidence)}
                />
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card variant="outlined">
            <CardContent sx={{ textAlign: 'center' }}>
              <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                S – P time
              </Typography>
              <Typography variant="h4" fontWeight={800} sx={{ fontFamily: 'monospace' }}>
                {spDiff !== null ? `${spDiff}s` : '—'}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                (Wadati / distance estimate)
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* ── Phase cards ──────────────────────────────────────────────────────── */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <PhaseCard label="P" phase={result.p_phase} color="#00D4C8" />
        </Grid>
        <Grid item xs={12} md={6}>
          <PhaseCard label="S" phase={result.s_phase} color="#6C63FF" />
        </Grid>
      </Grid>

      {/* ── Probability curves ───────────────────────────────────────────────── */}
      <Card>
        <CardContent sx={{ p: { xs: 2, md: 3 } }}>
          <ConfidenceChart predictions={result} />
        </CardContent>
      </Card>

      {/* ── Full picks table ─────────────────────────────────────────────────── */}
      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight={600} mb={2}>
            Picks Summary
          </Typography>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Phase</strong></TableCell>
                  <TableCell align="center"><strong>Detected</strong></TableCell>
                  <TableCell align="right"><strong>Time (s)</strong></TableCell>
                  <TableCell align="right"><strong>Sample index</strong></TableCell>
                  <TableCell align="right"><strong>Confidence</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {[
                  { name: 'P-wave', phase: result.p_phase },
                  { name: 'S-wave', phase: result.s_phase },
                ].map(({ name, phase }) => (
                  <TableRow key={name}>
                    <TableCell>{name}</TableCell>
                    <TableCell align="center">
                      {phase.detected ? (
                        <CheckCircleIcon color="success" fontSize="small" />
                      ) : (
                        <CancelIcon color="disabled" fontSize="small" />
                      )}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace' }}>
                      {phase.detected ? phase.time_seconds.toFixed(2) : '—'}
                    </TableCell>
                    <TableCell align="right" sx={{ fontFamily: 'monospace' }}>
                      {phase.detected ? phase.sample_index.toLocaleString() : '—'}
                    </TableCell>
                    <TableCell align="right">
                      {phase.detected ? (
                        <Chip
                          label={`${(phase.confidence * 100).toFixed(1)}%`}
                          size="small"
                          color={detectionColor(phase.confidence)}
                        />
                      ) : (
                        '—'
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      <Divider />
      <Typography variant="caption" color="text.secondary" textAlign="center">
        Model: PhaseNet (TorchScript) · Dataset: STEAD · Sample rate: 100 Hz ·
        Detection threshold: {result.detection_threshold} · Pick threshold: 0.1
      </Typography>
    </Stack>
  )
}
