import { useState } from 'react'
import {
  Box,
  Button,
  Card,
  CardContent,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  TextField,
  Typography,
  Alert,
  Divider,
  Stack,
} from '@mui/material'
import { useNavigate } from 'react-router-dom'
import { useSnackbar } from 'notistack'

import FileUpload from '@/components/FileUpload'
import LoadingSpinner from '@/components/LoadingSpinner'
import ErrorAlert from '@/components/ErrorAlert'
import { usePrediction } from '@/hooks/usePhaseNet'
import { generateDemoWaveform, channelDataToRequest } from '@/utils/waveform'
import { N_SAMPLES } from '@/utils/validation'
import type { InputMethod } from '@/types'

export default function PredictionForm() {
  const navigate = useNavigate()
  const { enqueueSnackbar } = useSnackbar()
  const { mutate, isPending, error } = usePrediction()

  const [inputMethod, setInputMethod] = useState<InputMethod>('json')
  const [formError, setFormError] = useState<string | null>(null)

  // Controlled field state (avoids react-hook-form complexity for large array fields)
  const [jsonInput, setJsonInput] = useState('')
  const [eastChannel, setEastChannel] = useState('')
  const [northChannel, setNorthChannel] = useState('')
  const [verticalChannel, setVerticalChannel] = useState('')

  // ── Parse & validate input ────────────────────────────────────────────────
  function buildPayload(): [number[], number[], number[]] | null {
    setFormError(null)

    if (inputMethod === 'json') {
      const raw = jsonInput.trim()
      if (!raw) { setFormError('JSON input is required.'); return null }
      let parsed: unknown
      try { parsed = JSON.parse(raw) } catch {
        setFormError('Invalid JSON.'); return null
      }
      if (!Array.isArray(parsed) || parsed.length !== 3) {
        setFormError('JSON must be an array of exactly 3 channels.'); return null
      }
      for (let i = 0; i < 3; i++) {
        if (!Array.isArray((parsed as unknown[])[i]) || ((parsed as number[][])[i]).length !== N_SAMPLES) {
          setFormError(`Channel ${i} must have exactly ${N_SAMPLES} values.`); return null
        }
      }
      return parsed as [number[], number[], number[]]
    }

    // manual / csv (csv sets the same channel state fields)
    const parse = (s: string, label: string): number[] | null => {
      if (!s.trim()) { setFormError(`${label} is required.`); return null }
      const arr = s.split(',').map((v) => parseFloat(v.trim()))
      if (arr.some(isNaN)) { setFormError(`${label} contains non-numeric values.`); return null }
      if (arr.length !== N_SAMPLES) {
        setFormError(`${label} must have exactly ${N_SAMPLES} values (got ${arr.length}).`)
        return null
      }
      return arr
    }

    const east = parse(eastChannel, 'East channel')
    const north = parse(northChannel, 'North channel')
    const vert = parse(verticalChannel, 'Vertical channel')
    if (!east || !north || !vert) return null
    return [east, north, vert]
  }

  const handleSubmit = () => {
    const payload = buildPayload()
    if (!payload) return

    mutate(
      { data: payload },
      {
        onSuccess: () => {
          enqueueSnackbar('Prediction complete!', { variant: 'success' })
          navigate('/results')
        },
        onError: (err) => {
          enqueueSnackbar((err as { message?: string })?.message ?? 'Prediction failed.', {
            variant: 'error',
          })
        },
      },
    )
  }

  const handleDemo = () => {
    const demo = generateDemoWaveform()
    const payload = channelDataToRequest(demo)
    setJsonInput(JSON.stringify(payload))
    setInputMethod('json')
    enqueueSnackbar('Demo waveform loaded.', { variant: 'info' })
  }

  const handleCsvParsed = (east: number[], north: number[], vertical: number[]) => {
    setEastChannel(east.join(','))
    setNorthChannel(north.join(','))
    setVerticalChannel(vertical.join(','))
    setInputMethod('manual')
    enqueueSnackbar('CSV parsed — data loaded into channel fields.', { variant: 'success' })
  }

  const apiError = (error as { message?: string } | null)?.message

  return (
    <Card>
      <CardContent sx={{ p: { xs: 2, md: 4 } }}>
        <Typography variant="h5" fontWeight={700} gutterBottom>
          Submit Waveform
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={3}>
          Provide 3-channel seismic data (E, N, Z) sampled at 100 Hz for a 60-second window
          (6 000 samples per channel).
        </Typography>

        <ErrorAlert error={formError} onClose={() => setFormError(null)} />
        <ErrorAlert error={apiError} title="API Error" />

        {/* Input method selector */}
        <FormControl sx={{ mb: 3 }}>
          <FormLabel sx={{ fontWeight: 600, mb: 1 }}>Input method</FormLabel>
          <RadioGroup
            row
            value={inputMethod}
            onChange={(e) => setInputMethod(e.target.value as InputMethod)}
          >
            <FormControlLabel value="json" control={<Radio />} label="JSON array" />
            <FormControlLabel value="manual" control={<Radio />} label="Per-channel text" />
            <FormControlLabel value="csv" control={<Radio />} label="Upload CSV file" />
          </RadioGroup>
        </FormControl>

        {/* ── JSON input ─────────────────────────────────────────────────────── */}
        {inputMethod === 'json' && (
          <TextField
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            multiline
            minRows={5}
            maxRows={12}
            fullWidth
            label="JSON Waveform Data"
            placeholder={'[[e0,e1,...,e5999],[n0,...],[z0,...]]'}
            helperText={`Paste a JSON array of 3 channels, each with ${N_SAMPLES} floats: [[E], [N], [Z]]`}
            inputProps={{ style: { fontFamily: 'monospace', fontSize: 12 } }}
          />
        )}

        {/* ── Manual channel entry ───────────────────────────────────────────── */}
        {inputMethod === 'manual' && (
          <Stack spacing={2}>
            {[
              { label: 'East (E) Channel', value: eastChannel, onChange: setEastChannel },
              { label: 'North (N) Channel', value: northChannel, onChange: setNorthChannel },
              { label: 'Vertical (Z) Channel', value: verticalChannel, onChange: setVerticalChannel },
            ].map(({ label, value, onChange }) => (
              <TextField
                key={label}
                value={value}
                onChange={(e) => onChange(e.target.value)}
                fullWidth
                label={label}
                placeholder="0.01, 0.02, 0.03, …"
                multiline
                minRows={2}
                maxRows={4}
                inputProps={{ style: { fontFamily: 'monospace', fontSize: 11 } }}
                helperText={`Comma-separated floats — exactly ${N_SAMPLES} values`}
              />
            ))}
          </Stack>
        )}

        {/* ── CSV Upload ─────────────────────────────────────────────────────── */}
        {inputMethod === 'csv' && (
          <FileUpload onParsed={handleCsvParsed} onError={setFormError} />
        )}

        <Divider sx={{ my: 3 }} />

        <Box display="flex" gap={2} flexWrap="wrap">
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={handleSubmit}
            disabled={isPending}
            sx={{ minWidth: 160 }}
          >
            {isPending ? 'Running inference…' : 'Run PhaseNet'}
          </Button>

          <Button variant="outlined" size="large" onClick={handleDemo} disabled={isPending}>
            Load demo waveform
          </Button>
        </Box>

        {isPending && (
          <Box mt={3}>
            <LoadingSpinner message="PhaseNet is processing the waveform…" size={32} />
          </Box>
        )}

        <Alert severity="info" sx={{ mt: 3 }}>
          <strong>Required format:</strong> 3 channels (E · N · Z) × 6 000 samples ·
          100 Hz sample rate · 60 s window · float32 values
        </Alert>
      </CardContent>
    </Card>
  )
}
