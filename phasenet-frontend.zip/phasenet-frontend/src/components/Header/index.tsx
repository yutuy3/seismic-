import { Box, Typography, Chip } from '@mui/material'
import WavesIcon from '@mui/icons-material/Waves'

interface HeaderProps {
  title: string
  subtitle?: string
  badge?: string
}

export default function Header({ title, subtitle, badge }: HeaderProps) {
  return (
    <Box
      sx={{
        pt: { xs: 6, md: 10 },
        pb: { xs: 4, md: 6 },
        textAlign: 'center',
      }}
    >
      {badge && (
        <Chip
          icon={<WavesIcon sx={{ fontSize: '14px !important' }} />}
          label={badge}
          color="primary"
          size="small"
          sx={{ mb: 2, fontWeight: 600, fontSize: '0.75rem' }}
        />
      )}
      <Typography
        variant="h2"
        sx={{
          fontSize: { xs: '2rem', md: '3rem' },
          fontWeight: 800,
          lineHeight: 1.15,
          letterSpacing: '-0.04em',
          mb: 1.5,
        }}
      >
        {title}
      </Typography>
      {subtitle && (
        <Typography
          variant="h6"
          color="text.secondary"
          sx={{ fontWeight: 400, maxWidth: 640, mx: 'auto', lineHeight: 1.6 }}
        >
          {subtitle}
        </Typography>
      )}
    </Box>
  )
}
