import { AppBar, Toolbar, Box, Button, useScrollTrigger } from '@mui/material'
import { Link, useLocation } from 'react-router-dom'
import StatusIndicator from '@/components/StatusIndicator'
import ThemeToggle from '@/components/ThemeToggle'
import WavesIcon from '@mui/icons-material/Waves'

const NAV_LINKS = [
  { label: 'Home', to: '/' },
  { label: 'Predict', to: '/predict' },
  { label: 'Results', to: '/results' },
  { label: 'About', to: '/about' },
]

interface NavbarProps {
  themeMode: 'light' | 'dark'
  onThemeToggle: () => void
}

export default function Navbar({ themeMode, onThemeToggle }: NavbarProps) {
  const { pathname } = useLocation()
  const elevated = useScrollTrigger({ disableHysteresis: true, threshold: 0 })

  return (
    <AppBar
      position="sticky"
      elevation={elevated ? 4 : 0}
      sx={{
        bgcolor: 'background.paper',
        borderBottom: '1px solid',
        borderColor: 'divider',
        backdropFilter: 'blur(12px)',
      }}
    >
      <Toolbar sx={{ gap: 1 }}>
        {/* Logo */}
        <Box
          component={Link}
          to="/"
          display="flex"
          alignItems="center"
          gap={1}
          sx={{ textDecoration: 'none', color: 'primary.main', mr: 2 }}
        >
          <WavesIcon sx={{ fontSize: 28 }} />
          <Box
            component="span"
            sx={{
              fontWeight: 800,
              fontSize: '1.1rem',
              letterSpacing: '-0.03em',
              color: 'text.primary',
            }}
          >
            Phase<Box component="span" color="primary.main">Net</Box>
          </Box>
        </Box>

        {/* Navigation links */}
        <Box display="flex" gap={0.5} flexGrow={1}>
          {NAV_LINKS.map(({ label, to }) => (
            <Button
              key={to}
              component={Link}
              to={to}
              color={pathname === to ? 'primary' : 'inherit'}
              variant={pathname === to ? 'text' : 'text'}
              sx={{
                fontWeight: pathname === to ? 700 : 500,
                color: pathname === to ? 'primary.main' : 'text.secondary',
                '&:hover': { color: 'primary.main' },
              }}
            >
              {label}
            </Button>
          ))}
        </Box>

        {/* Right side */}
        <StatusIndicator />
        <ThemeToggle mode={themeMode} onToggle={onThemeToggle} />
      </Toolbar>
    </AppBar>
  )
}
