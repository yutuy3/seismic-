import {
  Box,
  Card,
  CardContent,
  Chip,
  Container,
  Divider,
  Link,
  List,
  ListItem,
  ListItemText,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Paper,
} from '@mui/material'
import Header from '@/components/Header'

const PIPELINE_STEPS = [
  {
    step: '1',
    name: 'Detrend',
    desc: 'Removes linear trend via least-squares fit (degree 1).',
  },
  {
    step: '2',
    name: 'Taper (5%)',
    desc: 'Cosine taper on both ends suppresses edge transients before filtering.',
  },
  {
    step: '3',
    name: 'Bandpass',
    desc: '4th-order zero-phase Butterworth filter, 1–45 Hz. Uses ObsPy when available, SciPy otherwise.',
  },
  {
    step: '4',
    name: 'Crop / Pad',
    desc: 'Deterministic centre crop to 6 000 samples (inference branch — no random offset).',
  },
  {
    step: '5',
    name: 'Normalise',
    desc: 'Per-channel z-score: zero mean, unit standard deviation.',
  },
]

const STACK = [
  { component: 'Model', value: 'PhaseNet (PyTorch TorchScript)' },
  { component: 'Dataset', value: 'STEAD_Dataset_A' },
  { component: 'Backend', value: 'Django 4.2 + DRF 3.15' },
  { component: 'Inference', value: 'torch.jit.load · @torch.no_grad()' },
  { component: 'Signal processing', value: 'ObsPy 1.4 / SciPy 1.13' },
  { component: 'Frontend', value: 'React 18 · TypeScript · MUI · Recharts' },
]

export default function AboutPage() {
  return (
    <Container maxWidth="md" sx={{ pb: 12 }}>
      <Header
        title="About PhaseNet"
        subtitle="A seismic phase picker trained on the Stanford Earthquake Dataset (STEAD) for a university conference submission."
        badge="Model documentation"
      />

      {/* Overview */}
      <Card sx={{ mb: 4 }}>
        <CardContent sx={{ p: { xs: 2, md: 4 } }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            Overview
          </Typography>
          <Typography variant="body1" color="text.secondary" lineHeight={1.8}>
            PhaseNet is a deep-learning model for seismic phase detection and arrival-time picking.
            This deployment uses a single model trained on <strong>STEAD_Dataset_A</strong>{' '}
            (Stanford Earthquake Dataset — global arrivals, isevilla). The model outputs three
            signals: a detection probability (earthquake vs. noise), and per-sample arrival
            probabilities for the P and S phases.
          </Typography>

          <Box mt={2} display="flex" gap={1} flexWrap="wrap">
            <Chip label="PyTorch 2.3" size="small" />
            <Chip label="STEAD" size="small" />
            <Chip label="PhaseNet" size="small" color="primary" />
            <Chip label="TorchScript" size="small" />
          </Box>
        </CardContent>
      </Card>

      {/* Preprocessing pipeline */}
      <Card sx={{ mb: 4 }}>
        <CardContent sx={{ p: { xs: 2, md: 4 } }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            Preprocessing pipeline
          </Typography>
          <Typography variant="body2" color="text.secondary" mb={3}>
            Applied independently to each of the three channels (E, N, Z):
          </Typography>

          <Stack spacing={2}>
            {PIPELINE_STEPS.map(({ step, name, desc }) => (
              <Box key={step} display="flex" gap={2}>
                <Box
                  sx={{
                    minWidth: 32,
                    height: 32,
                    borderRadius: '50%',
                    bgcolor: 'primary.main',
                    color: 'primary.contrastText',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    fontSize: 14,
                    flexShrink: 0,
                    mt: 0.25,
                  }}
                >
                  {step}
                </Box>
                <Box>
                  <Typography fontWeight={700}>{name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {desc}
                  </Typography>
                </Box>
              </Box>
            ))}
          </Stack>
        </CardContent>
      </Card>

      {/* Model I/O */}
      <Card sx={{ mb: 4 }}>
        <CardContent sx={{ p: { xs: 2, md: 4 } }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            Model input / output
          </Typography>

          <Typography variant="subtitle2" fontWeight={600} mt={2} mb={1}>
            Input tensor
          </Typography>
          <Box
            component="pre"
            sx={{
              bgcolor: 'background.default',
              borderRadius: 2,
              p: 2,
              fontFamily: 'monospace',
              fontSize: 13,
              overflow: 'auto',
            }}
          >
            {`Shape : (1, 3, 6000)   # batch × channels × samples
dtype : float32
Channels: E (East), N (North), Z (Vertical)`}
          </Box>

          <Typography variant="subtitle2" fontWeight={600} mt={3} mb={1}>
            Output dict (TorchScript strict=False)
          </Typography>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell><strong>Key</strong></TableCell>
                  <TableCell><strong>Shape</strong></TableCell>
                  <TableCell><strong>Description</strong></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {[
                  { key: 'detection', shape: '(1,)', desc: 'Sigmoid probability — earthquake or noise' },
                  { key: 'p_arrival_probs', shape: '(1, 6000)', desc: 'Per-sample P-wave arrival probability curve' },
                  { key: 's_arrival_probs', shape: '(1, 6000)', desc: 'Per-sample S-wave arrival probability curve' },
                ].map((row) => (
                  <TableRow key={row.key}>
                    <TableCell sx={{ fontFamily: 'monospace' }}>{row.key}</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace' }}>{row.shape}</TableCell>
                    <TableCell>{row.desc}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>

      {/* API endpoints */}
      <Card sx={{ mb: 4 }}>
        <CardContent sx={{ p: { xs: 2, md: 4 } }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            API endpoints
          </Typography>

          <List disablePadding>
            <ListItem disableGutters>
              <ListItemText
                primary={
                  <Box display="flex" alignItems="center" gap={1}>
                    <Chip label="GET" size="small" color="success" />
                    <Typography sx={{ fontFamily: 'monospace' }}>/api/health/</Typography>
                  </Box>
                }
                secondary="Returns backend status, model load state, and compute device."
              />
            </ListItem>
            <Divider />
            <ListItem disableGutters sx={{ mt: 1 }}>
              <ListItemText
                primary={
                  <Box display="flex" alignItems="center" gap={1}>
                    <Chip label="POST" size="small" color="primary" />
                    <Typography sx={{ fontFamily: 'monospace' }}>/api/predict/</Typography>
                  </Box>
                }
                secondary='Accepts { "data": [[E×6000], [N×6000], [Z×6000]] }, returns phase picks.'
              />
            </ListItem>
          </List>

          <Box mt={2} display="flex" gap={1}>
            <Link href="/api/docs/" target="_blank" rel="noopener">
              Swagger UI
            </Link>
            {' · '}
            <Link href="/api/redoc/" target="_blank" rel="noopener">
              ReDoc
            </Link>
            {' · '}
            <Link href="/api/schema/" target="_blank" rel="noopener">
              OpenAPI schema
            </Link>
          </Box>
        </CardContent>
      </Card>

      {/* Tech stack */}
      <Card>
        <CardContent sx={{ p: { xs: 2, md: 4 } }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            Tech stack
          </Typography>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableBody>
                {STACK.map(({ component, value }) => (
                  <TableRow key={component}>
                    <TableCell sx={{ fontWeight: 600, width: 160 }}>{component}</TableCell>
                    <TableCell sx={{ fontFamily: 'monospace', fontSize: 13 }}>{value}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Container>
  )
}
