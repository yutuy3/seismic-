import { Container } from '@mui/material'
import Header from '@/components/Header'
import PredictionForm from '@/components/PredictionForm'

export default function PredictionPage() {
  return (
    <Container maxWidth="md" sx={{ pb: 10 }}>
      <Header
        title="Run a Prediction"
        subtitle="Submit a 3-channel seismic waveform to PhaseNet. The model will return P & S phase picks with confidence scores."
        badge="POST /api/predict/"
      />
      <PredictionForm />
    </Container>
  )
}
