import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Container,
  Grid,
  Stack,
  Typography,
} from '@mui/material'
import { Link } from 'react-router-dom'
import WavesIcon from '@mui/icons-material/Waves'
import TravelExploreIcon from '@mui/icons-material/TravelExplore'
import SpeedIcon from '@mui/icons-material/Speed'
import BarChartIcon from '@mui/icons-material/BarChart'
import StatusIndicator from '@/components/StatusIndicator'

const FEATURES = [
  {
    icon: <WavesIcon sx={{ fontSize: 36, color: '#00D4C8' }} />,
    title: 'P & S Phase Picking',
    desc: 'Precisely detects P-wave and S-wave arrivals with sample-level accuracy (100 Hz resolution).',
  },
  {
    icon: <TravelExploreIcon sx={{ fontSize: 36, color: '#6C63FF' }} />,
    title: 'Earthquake Detection',
    desc: 'Sigmoid-based event classifier distinguishes seismic signals from background noise.',
  },
  {
    icon: <SpeedIcon sx={{ fontSize: 36, color: '#FFB300' }} />,
    title: 'Real-time Inference',
    desc: 'TorchScript model loaded once at startup — sub-second inference on GPU, fast on CPU.',
  },
  {
    icon: <BarChartIcon sx={{ fontSize: 36, color: '#00C853' }} />,
    title: 'Probability Curves',
    desc: 'Full 6 000-sample probability curves for both phases, rendered as interactive charts.',
  },
]

const SPECS = [
  { label: 'Sample rate', value: '100 Hz' },
  { label: 'Window length', value: '60 s' },
  { label: 'Input shape', value: '[3 × 6 000]' },
  { label: 'Channels', value: 'E · N · Z' },
  { label: 'Bandpass', value: '1–45 Hz' },
  { label: 'Filter order', value: 'Butterworth 4th (zero-phase)' },
  { label: 'Detection threshold', value: '0.5' },
  { label: 'Pick threshold', value: '0.1' },
]

export default function HomePage() {
  return (
    <Box>
      {/* ── Hero ─────────────────────────────────────────────────────────────── */}
      <Box
        sx={{
          background: (t) =>
            t.palette.mode === 'dark'
              ? 'linear-gradient(160deg, #0A0E1A 0%, #111827 60%, #0d1a2d 100%)'
              : 'linear-gradient(160deg, #e8f5ff 0%, #f5f7fa 60%)',
          pt: { xs: 10, md: 16 },
          pb: { xs: 8, md: 14 },
          textAlign: 'center',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* Decorative background wave */}
        <Box
          aria-hidden
          sx={{
            position: 'absolute',
            inset: 0,
            opacity: 0.04,
            backgroundImage:
              'repeating-linear-gradient(0deg, transparent, transparent 40px, #00D4C8 40px, #00D4C8 41px)',
          }}
        />

        <Container maxWidth="md" sx={{ position: 'relative' }}>
          <Box mb={2}>
            <StatusIndicator />
          </Box>

          <Chip
            label="PhaseNet on STEAD · University Conference Edition"
            color="primary"
            size="small"
            sx={{ mb: 3, fontWeight: 600 }}
          />

          <Typography
            variant="h1"
            sx={{
              fontSize: { xs: '2.5rem', md: '4rem' },
              fontWeight: 800,
              lineHeight: 1.1,
              letterSpacing: '-0.04em',
              mb: 2,
            }}
          >
            Seismic Phase
            <Box
              component="span"
              sx={{
                background: 'linear-gradient(135deg, #00D4C8, #6C63FF)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              {' '}Picker
            </Box>
          </Typography>

          <Typography
            variant="h5"
            color="text.secondary"
            sx={{ fontWeight: 400, maxWidth: 560, mx: 'auto', lineHeight: 1.6, mb: 5 }}
          >
            Submit 3-channel seismic waveforms and get precise P &amp; S phase picks from
            a PyTorch PhaseNet model trained on STEAD.
          </Typography>

          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="center">
            <Button
              component={Link}
              to="/predict"
              variant="contained"
              size="large"
              sx={{ px: 4, py: 1.5, fontSize: '1rem' }}
            >
              Run a prediction
            </Button>
            <Button
              component="a"
              href="/api/docs/"
              target="_blank"
              rel="noopener"
              variant="outlined"
              size="large"
              sx={{ px: 4, py: 1.5, fontSize: '1rem' }}
            >
              API docs
            </Button>
          </Stack>
        </Container>
      </Box>

      {/* ── Features ─────────────────────────────────────────────────────────── */}
      <Container maxWidth="lg" sx={{ py: { xs: 8, md: 12 } }}>
        <Typography variant="h3" fontWeight={700} textAlign="center" mb={6}>
          What it does
        </Typography>
        <Grid container spacing={3}>
          {FEATURES.map((f) => (
            <Grid item xs={12} sm={6} md={3} key={f.title}>
              <Card sx={{ height: '100%' }}>
                <CardContent sx={{ p: 3 }}>
                  <Box mb={1.5}>{f.icon}</Box>
                  <Typography variant="h6" fontWeight={700} gutterBottom>
                    {f.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" lineHeight={1.6}>
                    {f.desc}
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>

      {/* ── Model specs ──────────────────────────────────────────────────────── */}
      <Box sx={{ bgcolor: 'background.paper', py: { xs: 8, md: 10 } }}>
        <Container maxWidth="md">
          <Typography variant="h3" fontWeight={700} textAlign="center" mb={1}>
            Model specifications
          </Typography>
          <Typography
            variant="body1"
            color="text.secondary"
            textAlign="center"
            mb={6}
          >
            Derived directly from the STEAD training notebook
          </Typography>

          <Grid container spacing={2}>
            {SPECS.map(({ label, value }) => (
              <Grid item xs={6} sm={4} md={3} key={label}>
                <Card variant="outlined">
                  <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                    <Typography variant="caption" color="text.secondary" textTransform="uppercase">
                      {label}
                    </Typography>
                    <Typography
                      variant="body1"
                      fontWeight={700}
                      sx={{ fontFamily: 'monospace', mt: 0.5 }}
                    >
                      {value}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      {/* ── CTA ──────────────────────────────────────────────────────────────── */}
      <Container maxWidth="sm" sx={{ py: { xs: 8, md: 12 }, textAlign: 'center' }}>
        <Typography variant="h4" fontWeight={700} mb={2}>
          Ready to pick phases?
        </Typography>
        <Typography variant="body1" color="text.secondary" mb={4}>
          Paste your waveform JSON, upload a CSV, or load a demo trace.
        </Typography>
        <Button
          component={Link}
          to="/predict"
          variant="contained"
          size="large"
          sx={{ px: 6, py: 1.5, fontSize: '1rem' }}
        >
          Start predicting
        </Button>
      </Container>
    </Box>
  )
}
