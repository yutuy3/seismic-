import { Box, Button, Container, Typography } from '@mui/material'
import { Link } from 'react-router-dom'
import ArrowBackIcon from '@mui/icons-material/ArrowBack'
import Header from '@/components/Header'
import PredictionResults from '@/components/PredictionResults'
import { useCachedPrediction } from '@/hooks/usePhaseNet'

export default function ResultsPage() {
  const cached = useCachedPrediction()

  if (!cached) {
    return (
      <Container maxWidth="sm" sx={{ py: 12, textAlign: 'center' }}>
        <Typography variant="h5" fontWeight={700} gutterBottom>
          No results yet
        </Typography>
        <Typography variant="body1" color="text.secondary" mb={4}>
          Run a prediction first and the results will appear here.
        </Typography>
        <Button
          component={Link}
          to="/predict"
          variant="contained"
          startIcon={<ArrowBackIcon />}
        >
          Go to Predict
        </Button>
      </Container>
    )
  }

  return (
    <Container maxWidth="lg" sx={{ pb: 10 }}>
      <Header
        title="Prediction Results"
        subtitle="PhaseNet has processed your waveform. Review the detected phases below."
        badge={cached.predictions.is_earthquake ? '🌍 Seismic event' : '✅ No event'}
      />

      <Box mb={3}>
        <Button
          component={Link}
          to="/predict"
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          size="small"
        >
          New prediction
        </Button>
      </Box>

      <PredictionResults result={cached.predictions} />
    </Container>
  )
}
