import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { fetchHealth } from '@/api/healthApi'
import { postPredict } from '@/api/predictionApi'
import type { PredictRequest, PredictResponse } from '@/types'

// ── Keys ─────────────────────────────────────────────────────────────────────
export const queryKeys = {
  health: ['health'] as const,
  prediction: ['prediction'] as const,
}

// ── Health check (polls every 30 s) ─────────────────────────────────────────
export function useHealth() {
  return useQuery({
    queryKey: queryKeys.health,
    queryFn: fetchHealth,
    refetchInterval: 30_000,
    retry: 2,
    staleTime: 15_000,
  })
}

// ── Prediction mutation ───────────────────────────────────────────────────────
export function usePrediction() {
  const queryClient = useQueryClient()

  return useMutation<PredictResponse, Error, PredictRequest>({
    mutationFn: postPredict,
    onSuccess: (data) => {
      // Cache the latest result so Results page can read it without re-fetching
      queryClient.setQueryData(queryKeys.prediction, data)
    },
  })
}

// ── Read cached prediction (used on Results page) ────────────────────────────
export function useCachedPrediction(): PredictResponse | undefined {
  const queryClient = useQueryClient()
  return queryClient.getQueryData<PredictResponse>(queryKeys.prediction)
}
