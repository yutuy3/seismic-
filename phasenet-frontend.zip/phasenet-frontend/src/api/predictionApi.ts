import apiClient from './axios'
import type { PredictRequest, PredictResponse } from '@/types'

/** POST /api/predict/
 *  Submits a 3-channel seismic waveform (shape [3, 6000]) and returns phase picks.
 */
export async function postPredict(payload: PredictRequest): Promise<PredictResponse> {
  const { data } = await apiClient.post<PredictResponse>('/predict/', payload)
  return data
}
