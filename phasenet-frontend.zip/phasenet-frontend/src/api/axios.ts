import axios from 'axios'
import type { ApiError } from '@/types'

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8000/api'

const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 60_000, // 60 s — inference can be slow on CPU
})

// ── Response interceptor: normalise errors ───────────────────────────────────
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError: ApiError = {
      message: 'An unexpected error occurred.',
      status: error.response?.status,
    }

    if (error.response) {
      const data = error.response.data
      apiError.message = data?.detail ?? data?.message ?? `HTTP ${error.response.status}`
      apiError.detail = JSON.stringify(data)
    } else if (error.request) {
      apiError.message =
        'No response from server. Make sure the backend is running at ' + BASE_URL
    } else {
      apiError.message = error.message
    }

    return Promise.reject(apiError)
  },
)

export default apiClient
