import apiClient from './axios'
import type { HealthResponse } from '@/types'

/** GET /api/health/ */
export async function fetchHealth(): Promise<HealthResponse> {
  const { data } = await apiClient.get<HealthResponse>('/health/')
  return data
}
