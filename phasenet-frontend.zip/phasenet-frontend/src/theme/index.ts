import { createTheme, type PaletteMode } from '@mui/material'

// PhaseNet visual identity:
// Deep navy-black bg in dark mode, crisp off-white in light.
// Single vivid accent: electric teal (#00D4C8) for seismic "arrival" metaphor.
// Monospace font for data; Inter for prose.

const TEAL = '#00D4C8'
const TEAL_DARK = '#009E94'
const NAVY = '#0A0E1A'
const NAVY_PAPER = '#111827'

export function buildTheme(mode: PaletteMode) {
  return createTheme({
    palette: {
      mode,
      primary: {
        main: TEAL,
        dark: TEAL_DARK,
        contrastText: '#000',
      },
      secondary: {
        main: '#6C63FF',
        contrastText: '#fff',
      },
      error: { main: '#FF5252' },
      warning: { main: '#FFB300' },
      success: { main: '#00C853' },
      background:
        mode === 'dark'
          ? { default: NAVY, paper: NAVY_PAPER }
          : { default: '#F5F7FA', paper: '#FFFFFF' },
      text:
        mode === 'dark'
          ? { primary: '#E8EAF6', secondary: '#90A4AE' }
          : { primary: '#1A1A2E', secondary: '#546E7A' },
    },
    typography: {
      fontFamily: '"Inter", "Helvetica Neue", Arial, sans-serif',
      h1: { fontWeight: 800, letterSpacing: '-0.04em' },
      h2: { fontWeight: 700, letterSpacing: '-0.03em' },
      h3: { fontWeight: 700 },
      h4: { fontWeight: 600 },
      h5: { fontWeight: 600 },
      h6: { fontWeight: 600 },
      subtitle1: { fontWeight: 500 },
      body2: { fontSize: '0.875rem' },
      // monospace for sample indices / confidence values
      overline: {
        fontFamily: '"JetBrains Mono", "Fira Code", monospace',
        letterSpacing: '0.12em',
      },
    },
    shape: { borderRadius: 12 },
    components: {
      MuiButton: {
        styleOverrides: {
          root: {
            textTransform: 'none',
            fontWeight: 600,
            borderRadius: 8,
          },
          containedPrimary: {
            background: `linear-gradient(135deg, ${TEAL} 0%, ${TEAL_DARK} 100%)`,
            '&:hover': {
              background: `linear-gradient(135deg, ${TEAL_DARK} 0%, #007A72 100%)`,
            },
          },
        },
      },
      MuiCard: {
        styleOverrides: {
          root: {
            borderRadius: 16,
            boxShadow:
              mode === 'dark'
                ? '0 4px 24px rgba(0,0,0,0.5)'
                : '0 2px 16px rgba(0,0,0,0.08)',
          },
        },
      },
      MuiChip: {
        styleOverrides: {
          root: { borderRadius: 6, fontWeight: 600 },
        },
      },
      MuiTextField: {
        defaultProps: { variant: 'outlined', size: 'small' },
      },
      MuiCssBaseline: {
        styleOverrides: `
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
          * { box-sizing: border-box; }
          ::-webkit-scrollbar { width: 6px; }
          ::-webkit-scrollbar-thumb { background: ${TEAL_DARK}; border-radius: 3px; }
        `,
      },
    },
  })
}
