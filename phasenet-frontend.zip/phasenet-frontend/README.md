# PhaseNet Frontend

React 18 + TypeScript frontend for the **PhaseNet** seismic phase-picking API.

## Tech stack

| Layer | Library |
|---|---|
| UI framework | React 18 + TypeScript |
| Build tool | Vite 5 |
| Component library | Material UI (MUI) v5 |
| Routing | React Router v6 |
| Data fetching | TanStack Query (React Query) v5 |
| Forms | React Hook Form + Zod |
| HTTP client | Axios |
| Charts | Recharts |
| Notifications | Notistack |

## Prerequisites

- Node.js 18+
- The PhaseNet Django backend running at `http://localhost:8000`

## Setup

```bash
# 1. Clone / copy this directory
cd phasenet-frontend

# 2. Install dependencies
npm install

# 3. Configure the API URL
cp .env.example .env
# Edit .env if your backend runs on a different host/port

# 4. Start the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `VITE_API_BASE_URL` | `http://localhost:8000/api` | Base URL of the PhaseNet Django backend |

## Pages

| Route | Page | Description |
|---|---|---|
| `/` | Home | Overview, specs, CTA |
| `/predict` | Predict | Submit waveform (JSON / CSV text / CSV file) |
| `/results` | Results | Phase picks, probability charts, picks table |
| `/about` | About | Pipeline docs, model I/O, API reference |

## Input formats

The predict page accepts three input modes:

### JSON array (recommended)
```json
[
  [e0, e1, ..., e5999],
  [n0, n1, ..., n5999],
  [z0, z1, ..., z5999]
]
```

### Per-channel CSV text
Paste comma-separated floats (6 000 per channel) into each channel field.

### CSV file upload
Upload a `.csv` file with shape `[3 × 6000]` (3 rows, 6000 columns)  
or `[6000 × 3]` (6000 rows, 3 columns — auto-detected).

## API endpoints consumed

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/health/` | Backend & model status |
| `POST` | `/api/predict/` | Run PhaseNet inference |

Full interactive docs: `/api/docs/` (Swagger UI) · `/api/redoc/` (ReDoc)

## Build for production

```bash
npm run build
# Output: dist/
```

## Project structure

```
src/
├── api/              # Axios instance + typed API functions
├── components/       # Reusable UI components
├── hooks/            # React Query hooks
├── layouts/          # MainLayout (Navbar + Footer wrapper)
├── pages/            # Route-level page components
├── routes/           # Route config
├── theme/            # MUI theme (light + dark)
├── types/            # TypeScript interfaces
└── utils/            # Waveform parsing, validation, helpers
```
