"""
api/views.py

Two endpoints:
  GET  /api/health/   — liveness + model status
  POST /api/predict/  — full inference pipeline
"""
import logging

from drf_spectacular.utils import extend_schema, OpenApiExample
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import (
    PredictRequestSerializer,
    PredictResponseSerializer,
    HealthResponseSerializer,
)
from .services import model_loader, preprocessing, inference, postprocessing

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
class HealthView(APIView):
    """
    GET /api/health/

    Returns service liveness, whether the model is loaded, and the device.
    """

    @extend_schema(
        responses={200: HealthResponseSerializer},
        summary="Health check",
        description=(
            "Returns the API status, whether the PhaseNet model is loaded into memory, "
            "and which compute device is active (cuda or cpu)."
        ),
    )
    def get(self, request):
        loaded = model_loader.is_model_loaded()
        device = model_loader.get_device() if loaded else "not_loaded"
        return Response(
            {
                "status": "ok",
                "model_loaded": loaded,
                "device": device,
            }
        )


# ─────────────────────────────────────────────────────────────────────────────
class PredictView(APIView):
    """
    POST /api/predict/

    Full inference pipeline:
      validate → preprocess → inference → postprocess → respond
    """

    @extend_schema(
        request=PredictRequestSerializer,
        responses={200: PredictResponseSerializer},
        summary="Seismic phase prediction",
        description=(
            "Accepts a 3-component seismic waveform (E, N, Z channels at 100 Hz) "
            "and returns:\n"
            "- Detection probability (is it an earthquake?)\n"
            "- P-phase pick: sample index, time in seconds, confidence\n"
            "- S-phase pick: sample index, time in seconds, confidence\n"
            "- Full 6000-point probability curves for P and S arrivals\n\n"
            "**Input shape**: `data` should be a list of 1–3 channels, "
            "each channel a list of 6 000 float amplitude values."
        ),
        examples=[
            OpenApiExample(
                "Minimal request (synthetic)",
                request_only=True,
                value={
                    "data": [
                        [0.0] * 6000,   # East channel
                        [0.0] * 6000,   # North channel
                        [0.0] * 6000,   # Vertical channel
                    ]
                },
            )
        ],
    )
    def post(self, request):
        # ── 1. Validate input ───────────────────────────────────────────────
        ser = PredictRequestSerializer(data=request.data)
        if not ser.is_valid():
            return Response(
                {"success": False, "errors": ser.errors},
                status=status.HTTP_400_BAD_REQUEST,
            )

        waveform = ser.validated_data["data"]   # (C, N) numpy float32

        # ── 2. Preprocess ───────────────────────────────────────────────────
        try:
            tensor = preprocessing.preprocess(waveform)     # (1, 3, 6000)
        except Exception as exc:
            logger.exception("Preprocessing failed")
            return Response(
                {"success": False, "error": f"Preprocessing error: {exc}"},
                status=status.HTTP_422_UNPROCESSABLE_ENTITY,
            )

        # ── 3. Inference ────────────────────────────────────────────────────
        try:
            raw = inference.run_inference(tensor)
        except FileNotFoundError as exc:
            logger.error("Model file missing: %s", exc)
            return Response(
                {"success": False, "error": str(exc)},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )
        except Exception as exc:
            logger.exception("Inference failed")
            return Response(
                {"success": False, "error": f"Inference error: {exc}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        # ── 4. Post-process ─────────────────────────────────────────────────
        try:
            result = postprocessing.postprocess(raw)
        except Exception as exc:
            logger.exception("Post-processing failed")
            return Response(
                {"success": False, "error": f"Post-processing error: {exc}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        return Response(result, status=status.HTTP_200_OK)
