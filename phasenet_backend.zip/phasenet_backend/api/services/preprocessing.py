"""
api/services/preprocessing.py

Replicates the SeismicPreprocessor from the training notebook (CELL 4) exactly.

Pipeline per channel:
  1. detrend       – remove linear trend
  2. taper         – 5 % cosine taper to suppress edge transients
  3. bandpass      – 1–45 Hz, 4th-order Butterworth, zero-phase
                     (ObsPy if available, scipy fallback)
  4. crop / pad    – deterministic centre-crop for inference
  5. normalise     – zero-mean, unit-std per channel

Input waveform:  (3, N) numpy float32 — 3 components (E, N, Z)
Output tensor:   torch.FloatTensor of shape (1, 3, 6000) ready for the model
"""
import logging

import numpy as np
import torch

logger = logging.getLogger(__name__)

# ── ObsPy optional ────────────────────────────────────────────────────────────
try:
    from obspy.signal.filter import bandpass as obspy_bandpass
    _OBSPY_OK = True
    logger.info("ObsPy bandpass filter available")
except ImportError:
    _OBSPY_OK = False
    logger.warning("ObsPy not available — using scipy Butterworth filter")

# ── Constants (must match notebook CELL 2) ────────────────────────────────────
SAMPLE_RATE = 100.0          # Hz
FREQ_MIN    = 1.0            # Hz  — low-cut
FREQ_MAX    = 45.0           # Hz  — high-cut
WINDOW_LEN  = 60.0           # seconds
N_SAMPLES   = int(WINDOW_LEN * SAMPLE_RATE)   # 6 000
N_CHANNELS  = 3


# ─────────────────────────────────────────────────────────────────────────────
class SeismicPreprocessor:
    """
    Stateless preprocessor — mirrors SeismicPreprocessor in CELL 4 of the
    training notebook, with augmentation disabled (inference mode only).
    """

    def __init__(
        self,
        sr: float = SAMPLE_RATE,
        fmin: float = FREQ_MIN,
        fmax: float = FREQ_MAX,
        window_len: float = WINDOW_LEN,
    ):
        self.sr   = sr
        self.fmin = fmin
        self.fmax = fmax
        self.ws   = int(window_len * sr)       # 6 000

    # ── per-channel transforms ─────────────────────────────────────────────

    def _detrend(self, s: np.ndarray) -> np.ndarray:
        """Remove linear trend (same as np.polyfit degree-1 in notebook)."""
        t = np.arange(len(s))
        coeffs = np.polyfit(t, s, 1)
        return s - np.polyval(coeffs, t)

    def _taper(self, s: np.ndarray, frac: float = 0.05) -> np.ndarray:
        """5 % cosine taper at both ends."""
        n  = len(s)
        tl = int(n * frac)
        w  = np.ones(n, dtype=np.float64)
        ramp_up   = 0.5 * (1 - np.cos(np.pi * np.arange(tl) / tl))
        ramp_down = 0.5 * (1 - np.cos(np.pi * np.arange(tl - 1, -1, -1) / tl))
        w[:tl]  = ramp_up
        w[-tl:] = ramp_down
        return s * w

    def _bandpass(self, s: np.ndarray) -> np.ndarray:
        """1–45 Hz 4th-order zero-phase Butterworth bandpass."""
        if _OBSPY_OK:
            return obspy_bandpass(
                s.astype(np.float64),
                self.fmin, self.fmax, self.sr,
                corners=4, zerophase=True,
            )
        from scipy.signal import butter, sosfiltfilt
        sos = butter(
            4, [self.fmin, self.fmax],
            btype="band", fs=self.sr, output="sos",
        )
        return sosfiltfilt(sos, s.astype(np.float64))

    def _normalize(self, s: np.ndarray, eps: float = 1e-8) -> np.ndarray:
        """Zero-mean, unit-std normalisation per channel."""
        return (s - s.mean()) / (s.std() + eps)

    def _crop_or_pad(self, s: np.ndarray) -> np.ndarray:
        """
        Deterministic centre-crop/pad to self.ws samples.
        Mirrors the inference branch (train=False) in the notebook.
        """
        n = len(s)
        if n < self.ws:
            pad = (self.ws - n) // 2
            s = np.pad(s, (pad, self.ws - n - pad))
        elif n > self.ws:
            start = (n - self.ws) // 2
            s = s[start: start + self.ws]
        return s

    # ── public API ────────────────────────────────────────────────────────

    def __call__(self, waveform: np.ndarray) -> np.ndarray:
        """
        Process a single waveform.

        Parameters
        ----------
        waveform : np.ndarray, shape (C, N) or (N, C) or (N,)
            Raw waveform.  C ≤ 3 channels, N samples.

        Returns
        -------
        out : np.ndarray, shape (3, 6000), dtype float32
            Preprocessed, ready for tensor conversion.
        """
        wf = np.asarray(waveform, dtype=np.float32)

        # Normalise shape to (C, N)
        if wf.ndim == 1:
            wf = wf[np.newaxis, :]               # (1, N)
        elif wf.shape[0] == self.ws or (wf.ndim == 2 and wf.shape[1] < wf.shape[0]):
            # Likely (N, C) layout — transpose
            wf = wf.T

        # Trim to 3 channels; pre-allocate zeroed output (missing channels = 0)
        out = np.zeros((N_CHANNELS, self.ws), dtype=np.float32)

        n_ch = min(N_CHANNELS, wf.shape[0])
        for c in range(n_ch):
            s = wf[c].astype(np.float64)
            s = self._detrend(s)
            s = self._taper(s)
            try:
                s = self._bandpass(s)
            except Exception as exc:
                logger.warning(
                    "Bandpass filter failed on channel %d (%s) — using unfiltered signal", c, exc
                )
            s = self._crop_or_pad(s)
            s = self._normalize(s)
            out[c] = s.astype(np.float32)

        return out


# ── Module-level singleton ────────────────────────────────────────────────────
_preprocessor = SeismicPreprocessor()


def preprocess(waveform) -> torch.Tensor:
    """
    Preprocess a raw waveform and return a batched tensor ready for the model.

    Parameters
    ----------
    waveform : list | np.ndarray
        Shape (3, 6000), (6000, 3), or (3, N) / (N, 3).
        May also be a plain Python list of lists.

    Returns
    -------
    torch.FloatTensor, shape (1, 3, 6000)
    """
    arr = np.asarray(waveform, dtype=np.float32)
    processed = _preprocessor(arr)                # (3, 6000) float32
    tensor = torch.from_numpy(processed).float()  # (3, 6000)
    return tensor.unsqueeze(0)                    # (1, 3, 6000)
