"""
api/services/postprocessing.py

Post-processes raw model output into human-readable predictions.

Logic mirrors the notebook's evaluation / decode step:
  - Detection: threshold at 0.5 (binary: earthquake / noise)
  - P/S picks:  argmax of probability curves  →  sample index  →  seconds
  - Confidence: peak probability value at argmax (0–1 float)
  - Threshold:  only report a pick when peak prob ≥ PICK_THRESHOLD
"""
import logging

import numpy as np

logger = logging.getLogger(__name__)

SAMPLE_RATE      = 100.0   # Hz  — must match notebook
DETECTION_THRESH = 0.5     # binary classification threshold
PICK_THRESHOLD   = 0.1     # minimum peak probability to report a pick


def _decode_pick(probs: list[float]) -> dict:
    """
    Given a probability curve (length 6000), return:
      sample_index  – int   (argmax)
      time_seconds  – float (sample_index / SAMPLE_RATE)
      confidence    – float (peak probability)
      detected      – bool  (confidence ≥ PICK_THRESHOLD)
    """
    arr = np.asarray(probs, dtype=np.float32)
    idx = int(np.argmax(arr))
    conf = float(arr[idx])
    return {
        "sample_index":  idx,
        "time_seconds":  round(idx / SAMPLE_RATE, 4),
        "confidence":    round(conf, 6),
        "detected":      conf >= PICK_THRESHOLD,
    }


def postprocess(raw: dict) -> dict:
    """
    Convert raw inference output to the final API response payload.

    Parameters
    ----------
    raw : dict
        Output of inference.run_inference():
          - "detection"       : float
          - "p_arrival_probs" : list[float] len 6000
          - "s_arrival_probs" : list[float] len 6000

    Returns
    -------
    dict  (matches the /api/predict/ response schema)
    """
    det_prob   = float(raw["detection"])
    is_event   = det_prob >= DETECTION_THRESH

    p_info = _decode_pick(raw["p_arrival_probs"])
    s_info = _decode_pick(raw["s_arrival_probs"])

    return {
        "success": True,
        "predictions": {
            # ── Detection ──────────────────────────────────────────────────
            "is_earthquake":         is_event,
            "detection_probability": round(det_prob, 6),
            "detection_threshold":   DETECTION_THRESH,

            # ── P-phase ────────────────────────────────────────────────────
            "p_phase": {
                "detected":      p_info["detected"],
                "sample_index":  p_info["sample_index"],
                "time_seconds":  p_info["time_seconds"],
                "confidence":    p_info["confidence"],
            },

            # ── S-phase ────────────────────────────────────────────────────
            "s_phase": {
                "detected":      s_info["detected"],
                "sample_index":  s_info["sample_index"],
                "time_seconds":  s_info["time_seconds"],
                "confidence":    s_info["confidence"],
            },

            # ── Full probability curves (optional — useful for plotting) ──
            "p_arrival_probs": raw["p_arrival_probs"],
            "s_arrival_probs": raw["s_arrival_probs"],
        },
    }
