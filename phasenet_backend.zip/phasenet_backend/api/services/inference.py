"""
api/services/inference.py

Runs the preprocessed tensor through the TorchScript PhaseNet model.

The TorchScript model was saved with strict=False (CELL: SAVE BEST MODEL),
so its forward method returns a dict:
  {
    "detection":        Tensor(B,)        — sigmoid detection probability
    "p_arrival_probs":  Tensor(B, 6000)   — per-sample P-pick probability
    "s_arrival_probs":  Tensor(B, 6000)   — per-sample S-pick probability
  }
"""
import logging

import torch

from .model_loader import get_model

logger = logging.getLogger(__name__)


@torch.no_grad()
def run_inference(tensor: torch.Tensor) -> dict:
    """
    Run PhaseNet inference.

    Parameters
    ----------
    tensor : torch.FloatTensor, shape (1, 3, 6000)
        Output of preprocessing.preprocess().

    Returns
    -------
    dict with keys:
        "detection"       – float scalar   (0–1)
        "p_arrival_probs" – list[float]    length 6000
        "s_arrival_probs" – list[float]    length 6000
    """
    model, device_str = get_model()
    device = torch.device(device_str)

    inp = tensor.to(device)
    out = model(inp)

    # TorchScript strict=False returns a dict
    detection       = out["detection"]        # Tensor (1,)
    p_arrival_probs = out["p_arrival_probs"]  # Tensor (1, 6000)
    s_arrival_probs = out["s_arrival_probs"]  # Tensor (1, 6000)

    return {
        "detection":       float(detection.squeeze().cpu().item()),
        "p_arrival_probs": p_arrival_probs.squeeze(0).cpu().tolist(),
        "s_arrival_probs": s_arrival_probs.squeeze(0).cpu().tolist(),
    }
