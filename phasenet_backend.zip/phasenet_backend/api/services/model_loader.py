"""
api/services/model_loader.py

Loads phasenet_stead_a_best_script.pt exactly once when Django starts.
Implements a thread-safe singleton using a module-level lock so the model
is never reloaded on subsequent requests.
"""
import logging
import threading
from pathlib import Path

import torch
from django.conf import settings

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_model = None
_device = None


def get_model():
    """
    Return (model, device_str) — loading from disk only on the first call.
    Thread-safe: uses a double-checked lock pattern.
    """
    global _model, _device

    if _model is not None:
        return _model, _device

    with _lock:
        if _model is not None:       # another thread may have loaded while we waited
            return _model, _device

        model_path = Path(settings.MODEL_PATH)
        if not model_path.exists():
            raise FileNotFoundError(
                f"PhaseNet model file not found: {model_path}\n"
                "Place phasenet_stead_a_best_script.pt in the models/ directory "
                "or set the MODEL_PATH environment variable."
            )

        device_str = "cuda" if torch.cuda.is_available() else "cpu"
        device = torch.device(device_str)

        logger.info("Loading PhaseNet TorchScript model from %s on %s …", model_path, device_str)
        model = torch.jit.load(str(model_path), map_location=device)
        model.eval()

        _model = model
        _device = device_str
        logger.info("PhaseNet model loaded successfully (device=%s)", device_str)

    return _model, _device


def is_model_loaded() -> bool:
    return _model is not None


def get_device() -> str:
    """Return the device string ('cuda' or 'cpu').  Loads model if needed."""
    _, dev = get_model()
    return dev
