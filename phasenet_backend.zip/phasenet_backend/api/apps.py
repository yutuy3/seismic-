"""
api/apps.py

Loads the PhaseNet model into memory when Django finishes starting up.
This guarantees the first real request never waits for a cold load.
"""
import logging

from django.apps import AppConfig

logger = logging.getLogger(__name__)


class ApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api"

    def ready(self):
        """Called once by Django after all apps are loaded."""
        try:
            from .services.model_loader import get_model
            get_model()
        except FileNotFoundError as exc:
            logger.warning(
                "PhaseNet model not found at startup — place the .pt file "
                "in models/ before serving predictions.\n%s", exc
            )
        except Exception as exc:
            logger.error("Failed to load PhaseNet model at startup: %s", exc)
