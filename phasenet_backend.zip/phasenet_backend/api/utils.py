"""
api/utils.py

- custom_exception_handler : wraps DRF exceptions in a consistent envelope
- model warmup              : triggered in api/apps.py on Django startup
"""
import logging

from rest_framework.views import exception_handler
from rest_framework.response import Response

logger = logging.getLogger(__name__)


def custom_exception_handler(exc, context):
    """
    Wrap all DRF exceptions in a consistent JSON envelope:
    { "success": false, "error": "<message>", "detail": <original_detail> }
    """
    response = exception_handler(exc, context)

    if response is not None:
        original = response.data
        response.data = {
            "success": False,
            "error":   str(original) if not isinstance(original, dict) else original.get("detail", str(original)),
            "detail":  original,
        }

    return response
