"""
api/serializers.py

Request / Response serializers for the PhaseNet API.

Waveform input format (as defined by the notebook):
  - 3-component seismic waveform
  - 3 channels: East (E), North (N), Vertical (Z)
  - 100 Hz sample rate
  - 60-second window → 6 000 samples per channel
  - Expected shape: (3, 6000) supplied as a nested list

The API accepts the raw waveform as a list-of-lists and handles
all shape validation here before preprocessing begins.
"""
import numpy as np
from rest_framework import serializers

N_CHANNELS      = 3
N_SAMPLES       = 6000      # 60 s × 100 Hz
MIN_SAMPLES     = 100       # absolute minimum (will be zero-padded)
MAX_SAMPLES     = 12000     # guard against absurdly large uploads


class PredictRequestSerializer(serializers.Serializer):
    """
    Validates the POST /api/predict/ request body.

    Expected JSON:
    {
      "data": [
        [<float>, ...],   // channel 0 — East
        [<float>, ...],   // channel 1 — North
        [<float>, ...],   // channel 2 — Vertical
      ]
    }

    Accepts 1–3 channels; missing channels are zero-filled by the
    preprocessor.  Each channel must have MIN_SAMPLES–MAX_SAMPLES values.
    """

    data = serializers.ListField(
        child=serializers.ListField(
            child=serializers.FloatField(),
            min_length=MIN_SAMPLES,
            max_length=MAX_SAMPLES,
        ),
        min_length=1,
        max_length=N_CHANNELS,
        help_text=(
            "Waveform data as a list of channels. "
            "Each channel is a list of float amplitude values sampled at 100 Hz. "
            "Provide 1–3 channels (E, N, Z). Expected length per channel: 6 000 samples."
        ),
    )

    def validate_data(self, value):
        """Ensure all channels have the same length and convert to numpy."""
        lengths = [len(ch) for ch in value]
        if len(set(lengths)) != 1:
            raise serializers.ValidationError(
                f"All channels must have the same number of samples. "
                f"Got lengths: {lengths}"
            )
        n_samples = lengths[0]
        if n_samples < MIN_SAMPLES:
            raise serializers.ValidationError(
                f"Each channel must have at least {MIN_SAMPLES} samples. Got {n_samples}."
            )
        if n_samples > MAX_SAMPLES:
            raise serializers.ValidationError(
                f"Each channel must have at most {MAX_SAMPLES} samples. Got {n_samples}."
            )

        # Convert to numpy for downstream services
        try:
            arr = np.asarray(value, dtype=np.float32)
        except Exception as exc:
            raise serializers.ValidationError(
                f"Could not convert data to numeric array: {exc}"
            ) from exc

        if not np.all(np.isfinite(arr)):
            raise serializers.ValidationError(
                "Waveform contains NaN or infinite values. Please check your data."
            )

        return arr   # (C, N) float32 numpy array


# ── Response serializers (documentation only — serialized manually in views) ──

class PhasePickSerializer(serializers.Serializer):
    detected      = serializers.BooleanField()
    sample_index  = serializers.IntegerField()
    time_seconds  = serializers.FloatField()
    confidence    = serializers.FloatField()


class PredictionsSerializer(serializers.Serializer):
    is_earthquake            = serializers.BooleanField()
    detection_probability    = serializers.FloatField()
    detection_threshold      = serializers.FloatField()
    p_phase                  = PhasePickSerializer()
    s_phase                  = PhasePickSerializer()
    p_arrival_probs          = serializers.ListField(child=serializers.FloatField())
    s_arrival_probs          = serializers.ListField(child=serializers.FloatField())


class PredictResponseSerializer(serializers.Serializer):
    success     = serializers.BooleanField()
    predictions = PredictionsSerializer()


class HealthResponseSerializer(serializers.Serializer):
    status       = serializers.CharField()
    model_loaded = serializers.BooleanField()
    device       = serializers.CharField()
