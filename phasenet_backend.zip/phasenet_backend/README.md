# PhaseNet Backend API

Production-ready Django REST Framework backend for the **PhaseNet** seismic P/S-phase picker trained on the STEAD dataset.

---

## Architecture

```
POST /api/predict/
      │
      ▼
PredictRequestSerializer      ← validates (3, 6000) waveform
      │
      ▼
SeismicPreprocessor            ← detrend → taper → bandpass → crop → normalize
      │                          (exact replica of notebook CELL 4)
      ▼
PhaseNet TorchScript model     ← loaded once at startup, reused across requests
      │                          output: {detection, p_arrival_probs, s_arrival_probs}
      ▼
postprocess()                  ← argmax picks, time conversion, confidence thresholds
      │
      ▼
JSON response
```

## Prerequisites

- Python 3.11+
- PostgreSQL 14+
- `phasenet_stead_a_best_script.pt` (TorchScript model file)

---

## Local Setup

### 1. Clone & enter the project

```bash
git clone <your-repo-url>
cd phasenet_backend
```

### 2. Create a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Place the model file

```bash
cp /path/to/phasenet_stead_a_best_script.pt models/
```

### 5. Configure environment variables

```bash
cp .env.example .env
# Edit .env — set SECRET_KEY, DB_*, MODEL_PATH, CORS_ALLOWED_ORIGINS
```

### 6. Run migrations (creates tables if any are added later)

```bash
python manage.py migrate
```

### 7. Start the development server

```bash
python manage.py runserver
```

API is now live at `http://localhost:8000/`.

---

## Running with Docker

### 1. Place the model file

```bash
cp /path/to/phasenet_stead_a_best_script.pt models/
```

### 2. Copy and edit environment file

```bash
cp .env.example .env
# Set SECRET_KEY, DB_PASSWORD, CORS_ALLOWED_ORIGINS at minimum
```

### 3. Build and start

```bash
docker-compose up --build
```

The API is available at `http://localhost:8000/`.

### 4. Stop

```bash
docker-compose down          # keep DB data
docker-compose down -v       # also remove DB volume
```

---

## API Endpoints

### `GET /api/health/`

Returns service and model status.

**Response 200**
```json
{
  "status": "ok",
  "model_loaded": true,
  "device": "cuda"
}
```

---

### `POST /api/predict/`

Run full PhaseNet inference on a seismic waveform.

**Request body**
```json
{
  "data": [
    [<float>, ...],  // channel 0 — East    (6000 samples @ 100 Hz)
    [<float>, ...],  // channel 1 — North
    [<float>, ...]   // channel 2 — Vertical
  ]
}
```

Rules:
- 1–3 channels (missing channels are zero-filled)
- Each channel: 100–12 000 samples (model trained on 6 000 = 60 s @ 100 Hz)
- All channels must have the same length
- No NaN or infinite values

**Response 200**
```json
{
  "success": true,
  "predictions": {
    "is_earthquake": true,
    "detection_probability": 0.943,
    "detection_threshold": 0.5,
    "p_phase": {
      "detected": true,
      "sample_index": 2150,
      "time_seconds": 21.5,
      "confidence": 0.871
    },
    "s_phase": {
      "detected": true,
      "sample_index": 3420,
      "time_seconds": 34.2,
      "confidence": 0.762
    },
    "p_arrival_probs": [0.001, 0.002, ...],
    "s_arrival_probs": [0.001, 0.003, ...]
  }
}
```

**Error responses**

| Status | Meaning |
|--------|---------|
| 400 | Validation error (bad shape, NaN values, wrong field) |
| 422 | Preprocessing failed |
| 500 | Inference or post-processing error |
| 503 | Model file not found |

---

## API Usage Examples

### cURL

```bash
# Health check
curl http://localhost:8000/api/health/

# Predict (replace [...] with actual float arrays)
curl -X POST http://localhost:8000/api/predict/ \
  -H "Content-Type: application/json" \
  -d '{"data": [[0.1, 0.2, ...], [0.0, 0.1, ...], [0.3, 0.1, ...]]}'
```

### JavaScript Fetch

```javascript
const response = await fetch('http://localhost:8000/api/predict/', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    data: [
      eastChannel,    // Float32Array or regular array, length 6000
      northChannel,
      verticalChannel,
    ],
  }),
});

const result = await response.json();
if (result.success) {
  const { p_phase, s_phase, is_earthquake } = result.predictions;
  console.log('Earthquake detected:', is_earthquake);
  console.log('P-wave arrival:', p_phase.time_seconds, 's');
  console.log('S-wave arrival:', s_phase.time_seconds, 's');
}
```

### Axios

```javascript
import axios from 'axios';

const { data } = await axios.post('http://localhost:8000/api/predict/', {
  data: [eastChannel, northChannel, verticalChannel],
});

const { p_phase, s_phase, detection_probability } = data.predictions;
```

---

## Documentation

Swagger UI:  `http://localhost:8000/api/docs/`
ReDoc:        `http://localhost:8000/api/redoc/`
Raw schema:   `http://localhost:8000/api/schema/`

---

## Preprocessing pipeline (matches notebook exactly)

For each of the 3 seismic channels (E, N, Z):

1. **Detrend** — removes linear trend via least-squares fit
2. **Cosine taper** — 5 % taper at both ends to suppress spectral leakage
3. **Bandpass filter** — 1–45 Hz, 4th-order Butterworth, zero-phase  
   (uses ObsPy if installed, falls back to scipy)
4. **Centre crop / zero-pad** — deterministic crop to 6 000 samples
5. **Normalize** — zero-mean, unit-standard-deviation per channel

Augmentation (noise jitter, random roll, amplitude scaling) is **disabled** at inference.

---

## Model input / output

| | Shape | Description |
|---|---|---|
| **Input** | `(1, 3, 6000)` | Batch of 1, 3 channels, 6 000 samples |
| `detection` | `(1,)` | Sigmoid probability — is this an earthquake? |
| `p_arrival_probs` | `(1, 6000)` | Per-sample probability of P-phase arrival |
| `s_arrival_probs` | `(1, 6000)` | Per-sample probability of S-phase arrival |

Post-processing: picks are decoded as `argmax` of the probability curve; confidence is the peak value; time = `sample_index / 100.0` seconds.

---

## Project Structure

```
phasenet_backend/
├── manage.py
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
│
├── config/
│   ├── settings.py       ← Django + DRF + CORS + logging configuration
│   ├── urls.py           ← root URL routing + Swagger
│   ├── wsgi.py
│   └── asgi.py
│
├── api/
│   ├── apps.py           ← model loaded at Django startup
│   ├── views.py          ← HealthView, PredictView
│   ├── urls.py
│   ├── serializers.py    ← input validation + response schema
│   ├── utils.py          ← custom exception handler
│   └── services/
│       ├── model_loader.py   ← singleton TorchScript loader
│       ├── preprocessing.py  ← SeismicPreprocessor (notebook CELL 4)
│       ├── inference.py      ← @torch.no_grad() inference
│       └── postprocessing.py ← argmax decode, threshold, time conversion
│
└── models/
    └── phasenet_stead_a_best_script.pt   ← place model here
```
